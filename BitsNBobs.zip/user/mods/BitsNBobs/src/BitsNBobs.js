"use strict";
/**
 * Copyright: Jennacide
*/
Object.defineProperty(exports, "__esModule", { value: true });
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
let jenndb;
class BitsNBobs {
    constructor() {
        this.path = require('path');
        this.modName = this.path.basename(this.path.dirname(__dirname.split('/').pop()));
    }
    postDBLoad(container) {
        const logger = container.resolve("WinstonLogger");
        const db = container.resolve("DatabaseServer").getTables();
        const preAkiModLoader = container.resolve("PreAkiModLoader");
        const databaseImporter = container.resolve("ImporterUtil");
        const locales = db.locales.global;
        const { localization } = require("../config.json");
        jenndb = databaseImporter.loadRecursive(`${preAkiModLoader.getModPath(this.modName)}database/`);
        for (const i_item in jenndb.templates.items) {
            db.templates.items[i_item] = jenndb.templates.items[i_item];
        }
        for (const h_item of jenndb.templates.handbook.Items) {
            if (!db.templates.handbook.Items.find(i => i.Id == h_item.Id)) {
                db.templates.handbook.Items.push(h_item);
            }
        }
        for (const localeID in locales) {
            if (localization === "EN") {
                for (const locale in jenndb.locales.en) {
                    locales[localeID][locale] = jenndb.locales.en[locale];
                }
            }
        }
        for (const p_item in jenndb.templates.prices) {
            db.templates.prices[p_item] = jenndb.templates.prices[p_item];
        }
        for (const tradeName in db.traders) {
            if (tradeName === "54cb57776803fa99248b456e") {
                for (const ti_item of jenndb.traders.Therapist.items.list) {
                    if (!db.traders[tradeName].assort.items.find(i => i._id == ti_item._id)) {
                        db.traders[tradeName].assort.items.push(ti_item);
                    }
                }
                for (const tb_item in jenndb.traders.Therapist.barter_scheme) {
                    db.traders[tradeName].assort.barter_scheme[tb_item] = jenndb.traders.Therapist.barter_scheme[tb_item];
                }
                for (const tl_item in jenndb.traders.Therapist.loyalty_level_items) {
                    db.traders[tradeName].assort.loyal_level_items[tl_item] = jenndb.traders.Therapist.loyalty_level_items[tl_item];
                }
            }
            if (tradeName === "54cb50c76803fa8b248b4571") {
                for (const ti_item of jenndb.traders.Prapor.items.list) {
                    if (!db.traders[tradeName].assort.items.find(i => i._id == ti_item._id)) {
                        db.traders[tradeName].assort.items.push(ti_item);
                    }
                }
                for (const tb_item in jenndb.traders.Prapor.barter_scheme) {
                    db.traders[tradeName].assort.barter_scheme[tb_item] = jenndb.traders.Prapor.barter_scheme[tb_item];
                }
                for (const tl_item in jenndb.traders.Prapor.loyalty_level_items) {
                    db.traders[tradeName].assort.loyal_level_items[tl_item] = jenndb.traders.Prapor.loyalty_level_items[tl_item];
                }
            }
        }
        this.pushItems(container);
        this.pushBuffs(container);
        this.checkExclusions(container);
        logger.log("BitsNBobs locked n' loaded.", "magenta");
    }
    pushItems(container) {
        const db = container.resolve("DatabaseServer").getTables();
        const items = db.templates.items;
        items["5a7828548dc32e5a9c28b516"]._props.Chambers[0]._props.filters[0].Filter.push("WIP_Ammo");
        items["5a7828548dc32e5a9c28b516"]._props.Chambers[0]._props.filters[0].Filter.push("Tracer_Buckshot");
        items["5a7828548dc32e5a9c28b516"]._props.Slots[2]._props.filters[0].Filter.forEach(x => {
            items[x]._props.Cartridges[0]._props.filters[0].Filter.push("Tracer_Buckshot");
            items[x]._props.Cartridges[0]._props.filters[0].Filter.push("WIP_Ammo");
        });
        items["576165642459773c7a400233"]._props.Chambers[0]._props.filters[0].Filter.push("WIP_Ammo");
        items["576165642459773c7a400233"]._props.Chambers[0]._props.filters[0].Filter.push("Tracer_Buckshot");
        items["576165642459773c7a400233"]._props.Slots[7]._props.filters[0].Filter.forEach(x => {
            items[x]._props.Cartridges[0]._props.filters[0].Filter.push("Tracer_Buckshot");
            items[x]._props.Cartridges[0]._props.filters[0].Filter.push("WIP_Ammo");
        });
    }
    pushBuffs(container) {
        const gameGlobals = container.resolve("DatabaseServer").getTables().globals.config;
        const gameBuffs = gameGlobals.Health.Effects.Stimulator.Buffs;
        const additions = jenndb.globals.buffs;
        for (const stimBuff in additions) {
            gameBuffs[stimBuff] = additions[stimBuff];
        }
    }
    checkExclusions(container) {
        const configServer = container.resolve("ConfigServer");
        const botConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.BOT);
        const pmcConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.PMC);
        const { blacklistFromInventoryAI } = require("../config.json");
        if (typeof blacklistFromInventoryAI === "boolean") {
            if (blacklistFromInventoryAI === true) {
                pmcConfig.vestLoot.blacklist.push("J_Vitamins");
                pmcConfig.pocketLoot.blacklist.push("J_Vitamins");
                pmcConfig.backpackLoot.blacklist.push("J_Vitamins");
                logger.log("J_Vitamins removed from bots inventories.", "magenta");
            }
        }
    }
}
module.exports = { mod: new BitsNBobs() };
